package br.com.consumoauto

import android.content.Context
import java.util.Locale

enum class Fuel(val label: String) {
    ETANOL("Etanol"),
    GASOLINA("Gasolina");

    fun other(): Fuel = if (this == ETANOL) GASOLINA else ETANOL
}

/** Consumo oficial Inmetro/PBEV (km/l). */
data class CarProfile(
    val id: String,
    val name: String,
    val etanolCidade: Double,
    val etanolEstrada: Double,
    val gasolinaCidade: Double,
    val gasolinaEstrada: Double
) {
    fun cidade(fuel: Fuel) = if (fuel == Fuel.ETANOL) etanolCidade else gasolinaCidade
    fun estrada(fuel: Fuel) = if (fuel == Fuel.ETANOL) etanolEstrada else gasolinaEstrada
    fun media(fuel: Fuel) = (cidade(fuel) + estrada(fuel)) / 2.0

    /**
     * Km/l estimado para a velocidade média do trecho:
     * até 40 km/h usa o consumo urbano, acima de 80 km/h o rodoviário,
     * e entre os dois faz uma interpolação linear.
     */
    fun kmPorLitro(fuel: Fuel, velocidadeKmh: Double): Double {
        val t = ((velocidadeKmh - 40.0) / 40.0).coerceIn(0.0, 1.0)
        return cidade(fuel) + (estrada(fuel) - cidade(fuel)) * t
    }
}

object Cars {
    val all = listOf(
        CarProfile("city", "Honda City Touring 2025", 9.2, 10.5, 13.1, 15.2),
        CarProfile("tracker10", "Tracker 2024 1.0 Turbo", 7.8, 9.6, 11.2, 13.6),
        CarProfile("tracker12", "Tracker 2024 1.2 Turbo", 7.2, 9.2, 10.4, 13.2)
    )

    fun byId(id: String?): CarProfile = all.firstOrNull { it.id == id } ?: all[0]
}

class Settings(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("consumo", Context.MODE_PRIVATE)

    var carId: String
        get() = sp.getString("car", "city") ?: "city"
        set(v) { sp.edit().putString("car", v).apply() }

    var fuel: Fuel
        get() = try { Fuel.valueOf(sp.getString("fuel", "GASOLINA") ?: "GASOLINA") } catch (e: Exception) { Fuel.GASOLINA }
        set(v) { sp.edit().putString("fuel", v.name).apply() }

    var precoEtanol: Double
        get() = sp.getFloat("pe", 4.29f).toDouble()
        set(v) { sp.edit().putFloat("pe", v.toFloat()).apply() }

    var precoGasolina: Double
        get() = sp.getFloat("pg", 6.29f).toDouble()
        set(v) { sp.edit().putFloat("pg", v.toFloat()).apply() }

    /** Ajuste percentual sobre o consumo Inmetro (100 = igual ao Inmetro). */
    var ajuste: Int
        get() = sp.getInt("ajuste", 100)
        set(v) { sp.edit().putInt("ajuste", v).apply() }

    var history: String
        get() = sp.getString("hist", "") ?: ""
        set(v) { sp.edit().putString("hist", v).apply() }

    fun car(): CarProfile = Cars.byId(carId)
    fun preco(f: Fuel): Double = if (f == Fuel.ETANOL) precoEtanol else precoGasolina
}

object Fmt {
    private val br = Locale("pt", "BR")
    fun n(v: Double, casas: Int): String = String.format(br, "%.${casas}f", v)
    fun reais(v: Double): String = "R$ " + n(v, 2)
    fun parse(text: String): Double? = text.trim().replace(",", ".").toDoubleOrNull()
}
