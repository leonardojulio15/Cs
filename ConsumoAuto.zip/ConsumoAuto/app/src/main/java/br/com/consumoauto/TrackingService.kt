package br.com.consumoauto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.ServiceCompat

/** Serviço em primeiro plano que mantém o GPS ligado com a tela apagada. */
class TrackingService : Service() {

    companion object {
        const val ACTION_STOP = "br.com.consumoauto.STOP"
        private const val CHANNEL_ID = "viagem"
        private const val NOTIF_ID = 42
    }

    private var lastNotif = 0L

    private val listener: (TripTracker.Snapshot) -> Unit = { s ->
        val now = SystemClock.elapsedRealtime()
        if (s.running && now - lastNotif > 5000) {
            lastNotif = now
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(s))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            TripControl.stop(this)
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(TripTracker.snapshot()),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (e: Exception) {
            // Sem permissão para serviço em primeiro plano agora: mede direto.
            TripControl.startDirect(this)
            stopSelf()
            return START_NOT_STICKY
        }

        TripTracker.removeListener(listener)
        TripTracker.addListener(listener)
        if (!TripControl.startDirect(this)) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        TripTracker.removeListener(listener)
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Viagem em andamento", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(s: TripTracker.Snapshot): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Viagem: " + Fmt.n(s.distanceKm, 1) + " km • " + Fmt.reais(s.cost))
            .setContentText(Fmt.n(s.liters, 2) + " L • " + Fmt.n(s.kmplMedio, 1) + " km/l")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Parar", stop).build())
            .build()
    }
}
