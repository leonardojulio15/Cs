package br.com.consumoauto

import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.Locale
import java.util.concurrent.Executors

/** Descobre o nome da rua atual (Geocoder do Android, precisa de internet). */
object StreetResolver {

    @Volatile var street: String = ""
        private set
    @Volatile var area: String = ""
        private set

    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    private var lastLoc: Location? = null
    private var lastAt = 0L

    fun clear() {
        street = ""
        area = ""
        lastLoc = null
        lastAt = 0L
    }

    fun update(ctx: Context, loc: Location, onChange: () -> Unit) {
        if (busy || !Geocoder.isPresent()) return
        val now = SystemClock.elapsedRealtime()
        val prev = lastLoc
        if (prev != null && now - lastAt < 8000) return
        if (prev != null && prev.distanceTo(loc) < 40f && now - lastAt < 30000) return

        busy = true
        lastAt = now
        lastLoc = loc
        val app = ctx.applicationContext
        exec.execute {
            try {
                @Suppress("DEPRECATION")
                val list = Geocoder(app, Locale("pt", "BR")).getFromLocation(loc.latitude, loc.longitude, 1)
                val a = list?.firstOrNull()
                if (a != null) {
                    val rua = a.thoroughfare ?: a.getAddressLine(0)?.substringBefore(",") ?: ""
                    val bairro = listOfNotNull(a.subLocality, a.subAdminArea ?: a.locality)
                        .distinct().joinToString(" • ")
                    if (rua != street || bairro != area) {
                        street = rua
                        area = bairro
                        main.post { onChange() }
                    }
                }
            } catch (_: Exception) {
                // sem internet ou serviço indisponível: mantém o último nome
            } finally {
                busy = false
            }
        }
    }
}
