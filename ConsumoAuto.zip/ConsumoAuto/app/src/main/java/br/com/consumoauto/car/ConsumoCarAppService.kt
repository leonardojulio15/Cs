package br.com.consumoauto.car

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.car.app.CarAppService
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.Action
import androidx.car.app.model.CarColor
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.validation.HostValidator
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import br.com.consumoauto.Fmt
import br.com.consumoauto.Settings
import br.com.consumoauto.TrackingService
import br.com.consumoauto.TripTracker

/** Ponto de entrada do Android Auto. */
class ConsumoCarAppService : CarAppService() {
    // Uso pessoal (instalação fora da Play Store): aceita qualquer host.
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR

    override fun onCreateSession(): Session = ConsumoSession()
}

class ConsumoSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = TripScreen(carContext)
}

class TripScreen(carContext: CarContext) : Screen(carContext), DefaultLifecycleObserver {

    private var lastInvalidate = 0L

    private val listener: (TripTracker.Snapshot) -> Unit = {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInvalidate > 2000) {
            lastInvalidate = now
            invalidate()
        }
    }

    init {
        lifecycle.addObserver(this)
    }

    override fun onStart(owner: LifecycleOwner) {
        TripTracker.addListener(listener)
        invalidate()
    }

    override fun onStop(owner: LifecycleOwner) {
        TripTracker.removeListener(listener)
    }

    private fun hasLocation(): Boolean = ContextCompat.checkSelfPermission(
        carContext, Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    override fun onGetTemplate(): Template {
        if (!hasLocation()) {
            return MessageTemplate.Builder(
                "Abra o Consumo Auto no celular, toque em Iniciar e permita o acesso à localização."
            )
                .setTitle("Consumo Auto")
                .setHeaderAction(Action.APP_ICON)
                .build()
        }

        val s = TripTracker.snapshot()
        val settings = Settings(carContext)
        val car = settings.car()
        val fuel = settings.fuel

        val status = when {
            !s.running -> "Parado"
            s.gpsOk -> "Medindo"
            else -> "Aguardando GPS"
        }

        val pane = Pane.Builder()
            .addRow(
                Row.Builder()
                    .setTitle("Distância: " + Fmt.n(s.distanceKm, 1) + " km")
                    .addText(status + " • " + Fmt.n(s.speedKmh, 0) + " km/h")
                    .build()
            )
            .addRow(
                Row.Builder()
                    .setTitle("Gasto: " + Fmt.reais(s.cost))
                    .addText(Fmt.n(s.liters, 2) + " L de " + fuel.label.lowercase())
                    .build()
            )
            .addRow(
                Row.Builder()
                    .setTitle("Consumo: " + Fmt.n(s.kmplMedio, 1) + " km/l")
                    .addText(Fmt.reais(settings.preco(fuel)) + "/L • " + car.name)
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle(if (s.running) "Parar" else "Iniciar")
                    .setBackgroundColor(if (s.running) CarColor.RED else CarColor.GREEN)
                    .setOnClickListener { toggle() }
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle("Usar " + fuel.other().label)
                    .setOnClickListener {
                        settings.fuel = fuel.other()
                        invalidate()
                    }
                    .build()
            )
            .build()

        return PaneTemplate.Builder(pane)
            .setTitle("Consumo Auto")
            .setHeaderAction(Action.APP_ICON)
            .build()
    }

    private fun toggle() {
        try {
            if (TripTracker.running) {
                carContext.startService(
                    Intent(carContext, TrackingService::class.java).setAction(TrackingService.ACTION_STOP)
                )
            } else {
                carContext.startForegroundService(Intent(carContext, TrackingService::class.java))
            }
        } catch (e: Exception) {
            CarToast.makeText(carContext, "Inicie a viagem pelo celular", CarToast.LENGTH_LONG).show()
        }
        invalidate()
    }
}
