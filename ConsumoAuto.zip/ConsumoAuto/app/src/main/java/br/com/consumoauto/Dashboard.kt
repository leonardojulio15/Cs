package br.com.consumoauto

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Desenha o painel (velocímetro + taxímetro + rua) num quadrado de lado [s]. */
object DashboardRenderer {

    private const val MAX_KMH = 180.0

    private val cBg1 = Color.parseColor("#151B24")
    private val cBg2 = Color.parseColor("#06080B")
    private val cMuted = Color.parseColor("#8B95A5")
    private val cTrack = Color.parseColor("#232A35")
    private val cTick = Color.parseColor("#5A6576")
    private val cLabel = Color.parseColor("#AEB7C4")
    private val cWhite = Color.parseColor("#F2F5F9")
    private val cGreen = Color.parseColor("#2ECC71")
    private val cAmber = Color.parseColor("#FFB300")
    private val cRed = Color.parseColor("#FF5252")
    private val cBlue = Color.parseColor("#4F8CFF")
    private val cPanel = Color.parseColor("#030405")
    private val cPanelEdge = Color.parseColor("#2B3340")

    private val condensed: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val mono: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun renderBitmap(size: Int, snap: TripTracker.Snapshot, st: Settings): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        draw(Canvas(bmp), size.toFloat(), snap, st)
        return bmp
    }

    fun draw(c: Canvas, s: Float, snap: TripTracker.Snapshot, st: Settings) {
        val fuel = st.fuel
        val pad = s * 0.05f

        // ----- Fundo -----
        val bg = Paint()
        bg.shader = LinearGradient(0f, 0f, 0f, s, cBg1, cBg2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, bg)

        // ----- Cabeçalho: carro • combustível | status -----
        val small = TextPaint(Paint.ANTI_ALIAS_FLAG)
        small.color = cMuted
        small.textSize = s * 0.034f
        small.typeface = medium

        val (statusText, statusColor) = when {
            !snap.running -> "PARADO" to cTick
            snap.gpsOk -> "GPS OK" to cGreen
            else -> "BUSCANDO GPS" to cAmber
        }
        small.textAlign = Paint.Align.RIGHT
        c.drawText(statusText, s - pad, s * 0.075f, small)
        val statusW = small.measureText(statusText)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = statusColor
        c.drawCircle(s - pad - statusW - s * 0.025f, s * 0.063f, s * 0.012f, dot)

        small.textAlign = Paint.Align.LEFT
        val header = st.car().name + " • " + fuel.label
        c.drawText(ellipsize(header, small, s - 2 * pad - statusW - s * 0.06f), pad, s * 0.075f, small)

        // ----- Velocímetro -----
        val cx = s * 0.5f
        val cy = s * 0.375f
        val r = s * 0.25f
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        val v = snap.speedKmh.coerceIn(0.0, MAX_KMH)

        val track = Paint(Paint.ANTI_ALIAS_FLAG)
        track.style = Paint.Style.STROKE
        track.strokeWidth = s * 0.03f
        track.strokeCap = Paint.Cap.ROUND
        track.color = cTrack
        c.drawArc(oval, 150f, 240f, false, track)

        val arcColor = when {
            v < 60 -> cGreen
            v < 100 -> cAmber
            else -> cRed
        }
        if (v > 0.5) {
            val prog = Paint(track)
            prog.color = arcColor
            c.drawArc(oval, 150f, (240.0 * v / MAX_KMH).toFloat(), false, prog)
        }

        val tick = Paint(Paint.ANTI_ALIAS_FLAG)
        tick.color = cTick
        tick.strokeCap = Paint.Cap.ROUND
        val lbl = Paint(Paint.ANTI_ALIAS_FLAG)
        lbl.color = cLabel
        lbl.textSize = s * 0.032f
        lbl.textAlign = Paint.Align.CENTER
        lbl.typeface = condensed
        for (k in 0..18) {
            val value = k * 10
            val a = Math.toRadians(150.0 + value / MAX_KMH * 240.0)
            val major = k % 2 == 0
            val r1 = r - s * 0.035f
            val r2 = r1 - if (major) s * 0.04f else s * 0.02f
            tick.strokeWidth = if (major) s * 0.007f else s * 0.004f
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(cx + r1 * ca, cy + r1 * sa, cx + r2 * ca, cy + r2 * sa, tick)
            if (major) {
                val rl = r2 - s * 0.035f
                c.drawText(value.toString(), cx + rl * ca, cy + rl * sa + lbl.textSize * 0.35f, lbl)
            }
        }

        // Ponteiro
        val na = Math.toRadians(150.0 + v / MAX_KMH * 240.0)
        val needle = Paint(Paint.ANTI_ALIAS_FLAG)
        needle.color = cRed
        needle.strokeWidth = s * 0.012f
        needle.strokeCap = Paint.Cap.ROUND
        val tip = r * 0.80f
        val tail = r * 0.12f
        c.drawLine(
            cx - tail * cos(na).toFloat(), cy - tail * sin(na).toFloat(),
            cx + tip * cos(na).toFloat(), cy + tip * sin(na).toFloat(), needle
        )
        val hub = Paint(Paint.ANTI_ALIAS_FLAG)
        hub.color = cWhite
        c.drawCircle(cx, cy, s * 0.03f, hub)
        hub.color = cBg1
        c.drawCircle(cx, cy, s * 0.012f, hub)

        // Velocidade digital
        val big = Paint(Paint.ANTI_ALIAS_FLAG)
        big.color = cWhite
        big.textSize = s * 0.11f
        big.textAlign = Paint.Align.CENTER
        big.typeface = condensed
        c.drawText(Fmt.n(snap.speedKmh, 0), cx, cy + r * 0.70f, big)
        small.textAlign = Paint.Align.CENTER
        small.textSize = s * 0.032f
        c.drawText("km/h", cx, cy + r * 0.70f + s * 0.04f, small)

        // ----- Taxímetro -----
        val top = s * 0.615f
        val bottom = s * 0.83f
        val panel = RectF(pad, top, s - pad, bottom)
        val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
        pFill.color = cPanel
        c.drawRoundRect(panel, s * 0.03f, s * 0.03f, pFill)
        val pEdge = Paint(Paint.ANTI_ALIAS_FLAG)
        pEdge.style = Paint.Style.STROKE
        pEdge.strokeWidth = s * 0.004f
        pEdge.color = cPanelEdge
        c.drawRoundRect(panel, s * 0.03f, s * 0.03f, pEdge)

        val tag = Paint(Paint.ANTI_ALIAS_FLAG)
        tag.color = cAmber
        tag.textSize = s * 0.028f
        tag.typeface = condensed
        tag.letterSpacing = 0.15f
        c.drawText("TAXÍMETRO", pad + s * 0.03f, top + s * 0.045f, tag)
        tag.color = cMuted
        tag.letterSpacing = 0f
        tag.textAlign = Paint.Align.RIGHT
        c.drawText(Fmt.reais(st.preco(fuel)) + "/L", s - pad - s * 0.03f, top + s * 0.045f, tag)

        val led = Paint(Paint.ANTI_ALIAS_FLAG)
        led.color = cAmber
        led.typeface = mono
        led.setShadowLayer(s * 0.018f, 0f, 0f, cAmber)
        led.textSize = s * 0.045f
        c.drawText("R$", pad + s * 0.03f, top + s * 0.145f, led)
        led.textSize = s * 0.10f
        led.textAlign = Paint.Align.RIGHT
        c.drawText(Fmt.n(snap.cost, 2), s - pad - s * 0.03f, top + s * 0.145f, led)

        val info = TextPaint(Paint.ANTI_ALIAS_FLAG)
        info.color = cLabel
        info.textSize = s * 0.03f
        info.typeface = medium
        info.textAlign = Paint.Align.CENTER
        val infoText = Fmt.n(snap.distanceKm, 1) + " km   •   " + Fmt.n(snap.liters, 2) + " L   •   " +
            Fmt.n(snap.kmplMedio, 1) + " km/l"
        c.drawText(infoText, s / 2f, bottom - s * 0.025f, info)

        // ----- Rua -----
        val pinX = pad + s * 0.025f
        val pinY = s * 0.893f
        val pin = Paint(Paint.ANTI_ALIAS_FLAG)
        pin.color = cBlue
        c.drawCircle(pinX, pinY, s * 0.022f, pin)
        pin.color = cWhite
        c.drawCircle(pinX, pinY, s * 0.008f, pin)

        val textX = pad + s * 0.068f
        val avail = s - pad - textX
        val streetP = TextPaint(Paint.ANTI_ALIAS_FLAG)
        streetP.color = cWhite
        streetP.textSize = s * 0.044f
        streetP.typeface = condensed
        val street = when {
            snap.street.isNotBlank() -> snap.street
            snap.running -> "Localizando rua…"
            else -> "Inicie a viagem para ver a rua"
        }
        c.drawText(ellipsize(street, streetP, avail), textX, pinY + s * 0.012f, streetP)
        if (snap.area.isNotBlank()) {
            small.textAlign = Paint.Align.LEFT
            small.textSize = s * 0.029f
            c.drawText(ellipsize(snap.area, small, avail), textX, pinY + s * 0.052f, small)
        }
    }

    private fun ellipsize(text: String, paint: TextPaint, width: Float): String =
        TextUtils.ellipsize(text, paint, width.coerceAtLeast(1f), TextUtils.TruncateAt.END).toString()
}

/** Painel na tela do celular. */
class DashboardView(context: Context) : View(context) {

    var snapshot: TripTracker.Snapshot = TripTracker.snapshot()
        set(value) {
            field = value
            invalidate()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        DashboardRenderer.draw(canvas, width.toFloat(), snapshot, Settings(context))
    }
}
