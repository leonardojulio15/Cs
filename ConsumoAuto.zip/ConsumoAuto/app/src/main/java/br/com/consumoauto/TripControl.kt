package br.com.consumoauto

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper

/** Leitura do GPS, usada pelo serviço em primeiro plano ou diretamente (plano B). */
object GpsEngine : LocationListener {
    private var lm: LocationManager? = null
    private var appCtx: Context? = null

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start(ctx: Context): Boolean {
        if (lm != null) return true
        val c = ctx.applicationContext
        if (!hasPermission(c)) return false
        val manager = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return try {
            manager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper()
            )
            lm = manager
            appCtx = c
            true
        } catch (e: Exception) {
            false
        }
    }

    @Synchronized
    fun stop() {
        try { lm?.removeUpdates(this) } catch (_: Exception) { }
        lm = null
    }

    override fun onLocationChanged(location: Location) {
        val c = appCtx ?: return
        TripTracker.onLocation(c, location)
    }

    // Necessários em Android 8–10, onde estes métodos ainda são abstratos.
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
    override fun onProviderEnabled(provider: String) { }
    override fun onProviderDisabled(provider: String) { }
}

/** Iniciar/parar viagem — usado pelo celular e pelo Android Auto. */
object TripControl {

    /** Retorna false se não há permissão de localização. */
    fun start(ctx: Context): Boolean {
        if (TripTracker.running) return true
        if (!GpsEngine.hasPermission(ctx)) return false
        try {
            ctx.startForegroundService(Intent(ctx, TrackingService::class.java))
            return true
        } catch (e: Exception) {
            // Android não deixou abrir o serviço em segundo plano: mede direto.
            return startDirect(ctx)
        }
    }

    fun startDirect(ctx: Context): Boolean {
        if (!TripTracker.running) TripTracker.start(ctx)
        val ok = GpsEngine.start(ctx)
        if (!ok) TripTracker.stop(ctx)
        return ok
    }

    fun stop(ctx: Context) {
        TripTracker.stop(ctx)
        GpsEngine.stop()
        try { ctx.stopService(Intent(ctx, TrackingService::class.java)) } catch (_: Exception) { }
    }

    fun toggle(ctx: Context): Boolean =
        if (TripTracker.running) { stop(ctx); true } else start(ctx)
}
