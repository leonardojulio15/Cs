package br.com.consumoauto

import android.content.Context
import android.location.Location
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/** Estado da viagem atual, compartilhado entre celular, Android Auto e serviço de GPS. */
object TripTracker {

    data class Snapshot(
        val running: Boolean,
        val distanceKm: Double,
        val liters: Double,
        val cost: Double,
        val speedKmh: Double,
        val kmplAtual: Double,
        val startedAt: Long,
        val gpsOk: Boolean
    ) {
        val kmplMedio: Double get() = if (liters > 0.0) distanceKm / liters else kmplAtual
    }

    private val listeners = CopyOnWriteArrayList<(Snapshot) -> Unit>()

    @Volatile
    var running = false
        private set

    private var distanceKm = 0.0
    private var liters = 0.0
    private var cost = 0.0
    private var speedKmh = 0.0
    private var kmplAtual = 0.0
    private var startedAt = 0L
    private var lastFixAt = 0L
    private var last: Location? = null

    fun addListener(l: (Snapshot) -> Unit) { listeners.add(l) }
    fun removeListener(l: (Snapshot) -> Unit) { listeners.remove(l) }

    @Synchronized
    fun snapshot(): Snapshot = Snapshot(
        running, distanceKm, liters, cost, speedKmh, kmplAtual, startedAt,
        running && System.currentTimeMillis() - lastFixAt < 10_000
    )

    @Synchronized
    fun start(context: Context) {
        val s = Settings(context)
        distanceKm = 0.0
        liters = 0.0
        cost = 0.0
        speedKmh = 0.0
        kmplAtual = s.car().kmPorLitro(s.fuel, 0.0) * s.ajuste / 100.0
        startedAt = System.currentTimeMillis()
        lastFixAt = 0L
        last = null
        running = true
        notifyListeners()
    }

    @Synchronized
    fun stop(context: Context) {
        if (!running) return
        running = false
        speedKmh = 0.0
        if (distanceKm >= 0.05) saveHistory(context)
        notifyListeners()
    }

    @Synchronized
    fun onLocation(context: Context, loc: Location) {
        if (!running) return
        lastFixAt = System.currentTimeMillis()

        // Descarta leituras imprecisas
        if (loc.hasAccuracy() && loc.accuracy > 30f) { notifyListeners(); return }

        val prev = last
        if (prev == null) {
            last = loc
            speedKmh = if (loc.hasSpeed()) loc.speed * 3.6 else 0.0
            notifyListeners()
            return
        }

        val metros = prev.distanceTo(loc).toDouble()
        val dt = (loc.time - prev.time) / 1000.0
        if (dt <= 0.0) return

        val velTrecho = metros / dt * 3.6
        if (velTrecho > 250.0) return // salto de GPS, ignora

        speedKmh = if (loc.hasSpeed()) loc.speed * 3.6 else velTrecho

        // Parado: não acumula o "ruído" do GPS
        if (metros < 15.0 && speedKmh < 4.0) { notifyListeners(); return }

        val s = Settings(context)
        val fuel = s.fuel
        val kmpl = (s.car().kmPorLitro(fuel, velTrecho) * s.ajuste / 100.0).coerceAtLeast(1.0)
        val km = metros / 1000.0
        val l = km / kmpl

        kmplAtual = kmpl
        distanceKm += km
        liters += l
        cost += l * s.preco(fuel)
        last = loc
        notifyListeners()
    }

    private fun saveHistory(context: Context) {
        val s = Settings(context)
        val data = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(startedAt))
        val linha = listOf(
            data, s.car().name, s.fuel.label,
            Fmt.n(distanceKm, 1), Fmt.n(liters, 2), Fmt.n(cost, 2)
        ).joinToString("|")
        val linhas = (listOf(linha) + s.history.split("\n").filter { it.isNotBlank() }).take(20)
        s.history = linhas.joinToString("\n")
    }

    private fun notifyListeners() {
        val snap = snapshot()
        for (l in listeners) {
            try { l(snap) } catch (_: Exception) { }
        }
    }
}
