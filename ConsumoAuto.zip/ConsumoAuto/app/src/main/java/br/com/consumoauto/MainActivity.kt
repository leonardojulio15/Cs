package br.com.consumoauto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var settings: Settings
    private lateinit var dashboard: DashboardView
    private lateinit var btnToggle: Button
    private lateinit var spCar: Spinner
    private lateinit var rbEtanol: RadioButton
    private lateinit var rbGasolina: RadioButton
    private lateinit var etPrecoE: EditText
    private lateinit var etPrecoG: EditText
    private lateinit var etAjuste: EditText
    private lateinit var tvRecom: TextView
    private lateinit var tvHist: TextView
    private lateinit var btnBackground: Button

    private var wasRunning = false

    private val listener: (TripTracker.Snapshot) -> Unit = { s -> runOnUiThread { render(s) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        setContentView(buildUi())
        loadFields()
        updateRecommendation()
    }

    override fun onResume() {
        super.onResume()
        TripTracker.addListener(listener)
        render(TripTracker.snapshot())
        renderHistory()
        updateBackgroundButton()
        loadFields()
        updateRecommendation()
    }

    override fun onPause() {
        TripTracker.removeListener(listener)
        super.onPause()
    }

    // ---------- UI ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(value: String, size: Float = 14f, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = value
        tv.textSize = size
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setPadding(0, dp(10), 0, dp(2))
        return tv
    }

    private fun numberField(decimal: Boolean): EditText {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or
            (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
        return et
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(12), dp(16), dp(32))

        dashboard = DashboardView(this)
        root.addView(dashboard)

        btnToggle = Button(this)
        btnToggle.textSize = 20f
        btnToggle.setTextColor(Color.WHITE)
        btnToggle.setOnClickListener { toggleTrip() }
        val lpBtn = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64))
        lpBtn.topMargin = dp(12)
        root.addView(btnToggle, lpBtn)

        btnBackground = Button(this)
        btnBackground.setOnClickListener { askBackground() }
        root.addView(btnBackground)
        root.addView(label(
            "No carro: abra o Consumo Auto na área de mídia. Play inicia a viagem, Pause encerra.", 13f
        ))

        root.addView(label("Carro", 16f, true))
        spCar = Spinner(this)
        spCar.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Cars.all.map { it.name }
        )
        root.addView(spCar)

        root.addView(label("Combustível no tanque", 16f, true))
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        rbEtanol = RadioButton(this)
        rbEtanol.id = View.generateViewId()
        rbEtanol.text = "Etanol"
        rbGasolina = RadioButton(this)
        rbGasolina.id = View.generateViewId()
        rbGasolina.text = "Gasolina"
        rg.addView(rbEtanol)
        rg.addView(rbGasolina)
        root.addView(rg)

        root.addView(label("Preço do etanol (R$/litro)", 16f, true))
        etPrecoE = numberField(true)
        root.addView(etPrecoE)

        root.addView(label("Preço da gasolina (R$/litro)", 16f, true))
        etPrecoG = numberField(true)
        root.addView(etPrecoG)

        root.addView(label("Ajuste do consumo (%)", 16f, true))
        root.addView(label("100 = igual ao Inmetro. Se o seu carro faz 10% menos, use 90.", 13f))
        etAjuste = numberField(false)
        root.addView(etAjuste)

        val btnSave = Button(this)
        btnSave.text = "Salvar configurações"
        btnSave.setOnClickListener {
            saveFields()
            Toast.makeText(this, "Salvo", Toast.LENGTH_SHORT).show()
        }
        root.addView(btnSave)

        tvRecom = label("", 15f)
        root.addView(tvRecom)

        root.addView(label("Últimas viagens", 16f, true))
        tvHist = label("", 14f)
        root.addView(tvHist)

        root.addView(label(
            "Valores estimados a partir do consumo oficial (Inmetro) e da velocidade " +
                "medida pelo GPS. Tempo parado em marcha lenta não é contabilizado.", 12f
        ))

        val scroll = ScrollView(this)
        scroll.addView(root)
        return scroll
    }

    private fun loadFields() {
        val idx = Cars.all.indexOfFirst { it.id == settings.carId }
        spCar.setSelection(if (idx >= 0) idx else 0)
        if (settings.fuel == Fuel.ETANOL) rbEtanol.isChecked = true else rbGasolina.isChecked = true
        etPrecoE.setText(Fmt.n(settings.precoEtanol, 2))
        etPrecoG.setText(Fmt.n(settings.precoGasolina, 2))
        etAjuste.setText(settings.ajuste.toString())
    }

    private fun saveFields() {
        settings.carId = Cars.all[spCar.selectedItemPosition.coerceIn(0, Cars.all.size - 1)].id
        settings.fuel = if (rbEtanol.isChecked) Fuel.ETANOL else Fuel.GASOLINA
        Fmt.parse(etPrecoE.text.toString())?.let { if (it > 0) settings.precoEtanol = it }
        Fmt.parse(etPrecoG.text.toString())?.let { if (it > 0) settings.precoGasolina = it }
        etAjuste.text.toString().trim().toIntOrNull()?.let { settings.ajuste = it.coerceIn(50, 150) }
        loadFields()
        updateRecommendation()
    }

    private fun updateRecommendation() {
        val car = settings.car()
        val kmE = car.media(Fuel.ETANOL)
        val kmG = car.media(Fuel.GASOLINA)
        val custoKmE = settings.precoEtanol / kmE
        val custoKmG = settings.precoGasolina / kmG
        val limite = settings.precoGasolina * kmE / kmG
        val melhor = if (custoKmE < custoKmG) "ETANOL" else "GASOLINA"
        tvRecom.text = "Para o ${car.name}, compensa abastecer com $melhor.\n" +
            "Etanol: ${Fmt.reais(custoKmE)}/km • Gasolina: ${Fmt.reais(custoKmG)}/km\n" +
            "Etanol vale a pena até ${Fmt.reais(limite)} " +
            "(${Fmt.n(kmE / kmG * 100, 0)}% do preço da gasolina)."
    }

    private fun render(s: TripTracker.Snapshot) {
        dashboard.snapshot = s
        btnToggle.text = if (s.running) "PARAR VIAGEM" else "INICIAR VIAGEM"
        btnToggle.backgroundTintList = ColorStateList.valueOf(
            Color.parseColor(if (s.running) "#C62828" else "#1B7F3B")
        )
        if (wasRunning && !s.running) renderHistory()
        wasRunning = s.running
    }

    private fun renderHistory() {
        val linhas = settings.history.split("\n").filter { it.isNotBlank() }
        tvHist.text = if (linhas.isEmpty()) "Nenhuma viagem ainda." else linhas.joinToString("\n") { l ->
            val p = l.split("|")
            if (p.size >= 6) "${p[0]} • ${p[1]} • ${p[2]}: ${p[3]} km, ${p[4]} L, R$ ${p[5]}" else l
        }
    }

    // ---------- Viagem ----------

    private fun hasLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasBackground(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun toggleTrip() {
        if (TripTracker.running) {
            TripControl.stop(this)
            return
        }
        saveFields()
        if (hasLocation()) {
            startTracking()
        } else {
            val perms = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        }
    }

    private fun startTracking() {
        if (!TripControl.start(this)) {
            Toast.makeText(this, "Não foi possível ligar o GPS.", Toast.LENGTH_LONG).show()
        }
    }

    private fun askBackground() {
        if (!hasLocation()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 3
            )
            return
        }
        if (hasBackground()) {
            Toast.makeText(this, "Já está liberado.", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Escolha \"Permitir o tempo todo\".", Toast.LENGTH_LONG).show()
        requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
    }

    private fun updateBackgroundButton() {
        btnBackground.text = if (hasBackground())
            "✓ Localização liberada para o Android Auto"
        else
            "Liberar localização para o Android Auto"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (hasLocation()) startTracking()
            else Toast.makeText(this, "Sem permissão de localização o app não mede a distância.", Toast.LENGTH_LONG).show()
        }
        if (requestCode == 3 && hasLocation()) askBackground()
        updateBackgroundButton()
    }
}
