package br.com.consumoauto

import android.os.Bundle
import android.os.SystemClock
import android.support.v4.media.MediaBrowserCompat.MediaItem
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.media.MediaBrowserServiceCompat

/**
 * Android Auto enxerga o app como "mídia":
 *  - Play  = iniciar viagem
 *  - Pause = parar viagem
 *  - "Música tocando" = custo, km, litros e km/l em tempo real
 *  - Lista = resumo + atalhos para trocar combustível e carro
 */
class ConsumoMediaService : MediaBrowserServiceCompat() {

    companion object {
        private const val ROOT = "root"
        private const val ID_TOGGLE = "toggle"
        private const val ID_FUEL = "fuel"
        private const val ID_CAR = "car"
        private const val ACTION_FUEL = "troca_combustivel"
    }

    private lateinit var session: MediaSessionCompat
    private var lastList = 0L
    private var lastRunning = false
    private var art: android.graphics.Bitmap? = null
    private var artAt = 0L
    private var artRunning = false

    private val listener: (TripTracker.Snapshot) -> Unit = { s -> onTripUpdate(s) }

    override fun onCreate() {
        super.onCreate()
        session = MediaSessionCompat(this, "ConsumoAuto")
        session.setCallback(callback)
        session.isActive = true
        sessionToken = session.sessionToken
        TripTracker.addListener(listener)
        publish(TripTracker.snapshot())
    }

    override fun onDestroy() {
        TripTracker.removeListener(listener)
        session.isActive = false
        session.release()
        super.onDestroy()
    }

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?): MediaBrowserServiceCompat.BrowserRoot {
        val extras = Bundle()
        // Mostrar itens como lista (não grade)
        extras.putInt("android.media.browse.CONTENT_STYLE_PLAYABLE_HINT", 1)
        extras.putInt("android.media.browse.CONTENT_STYLE_BROWSABLE_HINT", 1)
        return MediaBrowserServiceCompat.BrowserRoot(ROOT, extras)
    }

    override fun onLoadChildren(parentId: String, result: MediaBrowserServiceCompat.Result<MutableList<MediaItem>>) {
        if (parentId != ROOT) {
            result.sendResult(mutableListOf())
            return
        }
        val s = TripTracker.snapshot()
        val st = Settings(this)
        val fuel = st.fuel
        val car = st.car()
        val items = mutableListOf(
            item(
                ID_TOGGLE,
                if (s.running) "■ Parar viagem" else "▶ Iniciar viagem",
                if (s.running) Fmt.n(s.distanceKm, 1) + " km • " + Fmt.reais(s.cost)
                else "Também dá para usar o Play/Pause"
            ),
            item(
                "info_custo",
                "Gasto: " + Fmt.reais(s.cost),
                Fmt.n(s.liters, 2) + " L • " + Fmt.n(s.kmplMedio, 1) + " km/l"
            ),
            item(
                "info_rua",
                if (s.street.isNotBlank()) s.street else "Rua: aguardando GPS",
                s.area
            ),
            item(
                "info_dist",
                "Distância: " + Fmt.n(s.distanceKm, 1) + " km",
                Fmt.n(s.speedKmh, 0) + " km/h • " + statusText(s)
            ),
            item(
                ID_FUEL,
                "Combustível: " + fuel.label + " (" + Fmt.reais(st.preco(fuel)) + "/L)",
                "Toque para usar " + fuel.other().label
            ),
            item(ID_CAR, "Carro: " + car.name, "Toque para trocar de carro")
        )
        result.sendResult(items)
    }

    private fun item(id: String, title: String, subtitle: String): MediaItem {
        val d = MediaDescriptionCompat.Builder()
            .setMediaId(id)
            .setTitle(title)
            .setSubtitle(subtitle)
            .build()
        return MediaItem(d, MediaItem.FLAG_PLAYABLE)
    }

    private fun statusText(s: TripTracker.Snapshot): String = when {
        !s.running -> "Parado"
        s.gpsOk -> "GPS ok"
        else -> "Aguardando GPS"
    }

    private fun onTripUpdate(s: TripTracker.Snapshot) {
        publish(s)
        val now = SystemClock.elapsedRealtime()
        if (s.running != lastRunning || now - lastList > 3000) {
            lastList = now
            lastRunning = s.running
            notifyChildrenChanged(ROOT)
        }
    }

    /** Atualiza o "tocando agora" e o estado Play/Pause. */
    private fun publish(s: TripTracker.Snapshot) {
        val st = Settings(this)
        val title = Fmt.reais(s.cost) + " • " + Fmt.n(s.speedKmh, 0) + " km/h"
        val sub = if (s.street.isNotBlank()) s.street
        else Fmt.n(s.distanceKm, 1) + " km • " + Fmt.n(s.liters, 2) + " L • " + Fmt.n(s.kmplMedio, 1) + " km/l"
        val album = Fmt.n(s.distanceKm, 1) + " km • " + Fmt.n(s.kmplMedio, 1) + " km/l • " +
            st.car().name + " • " + st.fuel.label

        // Painel desenhado como "capa do álbum" (a cada 2 s)
        val now = SystemClock.elapsedRealtime()
        if (art == null || now - artAt >= 2000 || artRunning != s.running) {
            artAt = now
            artRunning = s.running
            art = try { DashboardRenderer.renderBitmap(400, s, st) } catch (e: Exception) { art }
        }

        val meta = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, "viagem")
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_TITLE, title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, sub)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_SUBTITLE, sub)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_DESCRIPTION, album)
        art?.let {
            meta.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, it)
        }
        session.setMetadata(meta.build())

        val state = if (s.running) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or
                        PlaybackStateCompat.ACTION_PAUSE or
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or
                        PlaybackStateCompat.ACTION_STOP or
                        PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID
                )
                .addCustomAction(
                    PlaybackStateCompat.CustomAction.Builder(
                        ACTION_FUEL, "Usar " + st.fuel.other().label, R.drawable.ic_launcher
                    ).build()
                )
                .setState(state, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 0f)
                .build()
        )
    }

    private fun showError(msg: String) {
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID)
                .setState(PlaybackStateCompat.STATE_ERROR, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 0f)
                .setErrorMessage(PlaybackStateCompat.ERROR_CODE_APP_ERROR, msg)
                .build()
        )
    }

    private fun startTrip() {
        if (!TripControl.start(this)) {
            showError("Abra o Consumo Auto no celular e permita a localização")
            return
        }
        publish(TripTracker.snapshot())
        notifyChildrenChanged(ROOT)
    }

    private fun stopTrip() {
        TripControl.stop(this)
        publish(TripTracker.snapshot())
        notifyChildrenChanged(ROOT)
    }

    private fun switchFuel() {
        val st = Settings(this)
        st.fuel = st.fuel.other()
        publish(TripTracker.snapshot())
        notifyChildrenChanged(ROOT)
    }

    private fun nextCar() {
        val st = Settings(this)
        val i = Cars.all.indexOfFirst { it.id == st.carId }
        st.carId = Cars.all[(i + 1).mod(Cars.all.size)].id
        publish(TripTracker.snapshot())
        notifyChildrenChanged(ROOT)
    }

    private val callback = object : MediaSessionCompat.Callback() {
        override fun onPlay() = startTrip()
        override fun onPause() = stopTrip()
        override fun onStop() = stopTrip()

        override fun onPlayFromMediaId(mediaId: String?, extras: Bundle?) {
            when (mediaId) {
                ID_TOGGLE -> if (TripTracker.running) stopTrip() else startTrip()
                ID_FUEL -> switchFuel()
                ID_CAR -> nextCar()
                else -> publish(TripTracker.snapshot())
            }
        }

        override fun onCustomAction(action: String?, extras: Bundle?) {
            if (action == ACTION_FUEL) switchFuel()
        }
    }
}
