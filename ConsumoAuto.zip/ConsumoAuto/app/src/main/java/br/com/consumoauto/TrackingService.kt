package br.com.consumoauto

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.ServiceCompat

/** Serviço em primeiro plano que lê o GPS e alimenta o TripTracker. */
class TrackingService : Service(), LocationListener {

    companion object {
        const val ACTION_STOP = "br.com.consumoauto.STOP"
        private const val CHANNEL_ID = "viagem"
        private const val NOTIF_ID = 42
    }

    private var lm: LocationManager? = null
    private var lastNotif = 0L

    private val listener: (TripTracker.Snapshot) -> Unit = { s ->
        val now = SystemClock.elapsedRealtime()
        if (s.running && now - lastNotif > 5000) {
            lastNotif = now
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(s))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            TripTracker.stop(this)
            stopSelf()
            return START_NOT_STICKY
        }

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(TripTracker.snapshot()),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        )

        if (!TripTracker.running) TripTracker.start(this)
        TripTracker.removeListener(listener)
        TripTracker.addListener(listener)

        if (lm == null) {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            try {
                manager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper()
                )
                lm = manager
            } catch (e: SecurityException) {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { lm?.removeUpdates(this) } catch (_: Exception) { }
        lm = null
        TripTracker.removeListener(listener)
        TripTracker.stop(this)
        super.onDestroy()
    }

    override fun onLocationChanged(location: Location) {
        TripTracker.onLocation(this, location)
    }

    // Necessários em Android 8–10, onde estes métodos ainda são abstratos.
    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) { }
    override fun onProviderEnabled(provider: String) { }
    override fun onProviderDisabled(provider: String) { }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Viagem em andamento", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(s: TripTracker.Snapshot): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, TrackingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Viagem: " + Fmt.n(s.distanceKm, 1) + " km • " + Fmt.reais(s.cost))
            .setContentText(Fmt.n(s.liters, 2) + " L • " + Fmt.n(s.kmplAtual, 1) + " km/l")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Parar", stop).build())
            .build()
    }
}
