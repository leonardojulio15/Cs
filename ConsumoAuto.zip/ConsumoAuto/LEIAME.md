# Consumo Auto

App Android com tela no Android Auto que estima o consumo de etanol/gasolina
pela distância medida no GPS e pelo preço do litro informado.

## Como gerar o APK só pelo celular (GitHub, grátis)

1. Crie uma conta em github.com e um repositório novo (pode ser privado).
2. No repositório: **Add file → Create new file**. No nome, digite
   `.github/workflows/build.yml` e cole o conteúdo do arquivo `build.yml`.
   Toque em **Commit changes**.
3. **Add file → Upload files** e envie o arquivo `ConsumoAuto.zip` (sem descompactar).
   Toque em **Commit changes**.
4. Abra a aba **Actions** e aguarde ~5 minutos até o "Gerar APK" ficar verde.
5. Na página inicial do repositório, abra **Releases** e baixe `ConsumoAuto.apk`.

Se tiver PC com Android Studio, basta abrir a pasta `ConsumoAuto` e rodar.

## Instalar e liberar no Android Auto

1. Abra o APK no celular e permita "instalar apps desconhecidos".
2. Abra o Consumo Auto, configure carro, combustível e preços, e toque em
   **Iniciar viagem** uma vez para conceder a permissão de localização.
3. Android Auto (Configurações do celular → Android Auto) → toque várias vezes em
   **Versão** até ativar o modo desenvolvedor → menu ⋮ → **Configurações do
   desenvolvedor** → ative **Fontes desconhecidas**.
4. Em **Personalizar o inicializador**, marque o Consumo Auto. Ele aparece na área de mídia do carro.
5. No carro: **Play** inicia a viagem, **Pause** encerra. A "música tocando" mostra custo, km, litros e km/l.
   Na lista do app dá para trocar o combustível e o carro.

## Como o cálculo funciona

- A cada leitura do GPS, soma a distância do trecho.
- Km/l do trecho: consumo urbano Inmetro até 40 km/h, rodoviário acima de 80 km/h,
  interpolado entre os dois. Multiplicado pelo "ajuste %".
- Litros = km ÷ km/l; custo = litros × preço do combustível selecionado.
- Leituras com precisão pior que 30 m e saltos acima de 250 km/h são descartadas.

Consumo Inmetro usado (km/l, etanol cidade/estrada · gasolina cidade/estrada):

| Carro | Etanol | Gasolina |
|---|---|---|
| Honda City Touring 2025 | 9,2 / 10,5 | 13,1 / 15,2 |
| Tracker 2024 1.0 Turbo | 7,8 / 9,6 | 11,2 / 13,6 |
| Tracker 2024 1.2 Turbo | 7,2 / 9,2 | 10,4 / 13,2 |
